import discord
from discord.ext import commands, tasks
import os
import requests
import json
from colorama import Fore
import asyncio
from bs4 import BeautifulSoup
import sys
import re
from discord import File
import pymongo
from details import *
import datetime
import pytz
import random
import subprocess





bot = commands.Bot(command_prefix=prefix,self_bot=True)
intents = discord.Intents.default()
intents.members = True
intents.typing = False
intents.presences = False
intents.guilds = True
intents.emojis = True
intents.messages = True

current_directory = os.getcwd()

# Define the path for the "scraped" directory
directory_path = os.path.join(current_directory, "scraped")

# Create the "scraped" directory if it doesn't exist
if not os.path.exists(directory_path):
    os.makedirs(directory_path)


from discord import Activity, ActivityType

@bot.event
async def on_ready():
 print("Bot is ready")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("Command not found. Please check the command usage with `.help`.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"Missing required argument: {error.param.name}. Please check the command usage with `.help {ctx.command}`.")
    elif isinstance(error, commands.BadArgument):
        await ctx.send(f"Invalid argument provided. Please check the command usage with `.help {ctx.command}`.")
    elif isinstance(error, commands.CommandOnCooldown):
        await ctx.send(f"Command is on cooldown. Please try again later.")
    elif isinstance(error, commands.NoPrivateMessage):
        await ctx.send("This command cannot be used in private messages.")
    else:
        # Handle other errors or log them
        await ctx.send("An error occurred. Please try again.")



status_file = "status.txt"  # File to store statuses

@bot.command()
async def list_status(ctx):
    statuses = get_statuses()
    if not statuses:
        await ctx.send("No statuses available.")
    else:
        status_list = "\n".join([f"{index + 1}. {status}" for index, status in enumerate(statuses)])
        await ctx.send(f"Statuses:\n{status_list}")

@bot.command()
async def status_rotator_guide(ctx):
    guide_message = (
        "To use the status rotator, follow these steps:\n\n"
        "1. You must have Nitro for using custom emojis with statuses.\n"
        "2. Get the ID of the custom emoji using `.get_emoji_id`.\n"
        "3. Use `.add_status <status-text>, <emoji-id>` to add a status. "
        "You can also omit the `<emoji-id>` if you don't want to use a custom emoji.\n"
        "   Example: `.add_status Hello World!, 123456789012345678`\n"
        "   Use `,` as a separator between the status text and the emoji ID.\n"
        "4. Use `.list_status` to see the ongoing statuses.\n"
        "5. To remove a status, use `.remove_status <status-id>`. "
      "6. Please use .reset_status if you facing any issue or use .restart"
        "Please note that status IDs update in real time, so check with `.list_status` before removing.\n"
        "   Example: `.remove_status 1` to remove the first status in the list."
    )
    await ctx.send(guide_message)

@bot.command()
async def reset_status(ctx):
    # Clear the content of the status file
    with open(status_file, 'w') as file:
        file.write("")

    await ctx.send("Status file reset successfully.")

@bot.command()
async def add_status(ctx, *, arguments: str):
    # Split the arguments using ',' as the separator
    parts = arguments.split(',')

    if len(parts) < 1 or len(parts) > 2:
        await ctx.send("Invalid number of arguments. Usage: `.add_status <status>, [emoji_id]`")
        return

    status_text = parts[0].strip()
    emoji_id = parts[1].strip() if len(parts) == 2 else ""

    if len(status_text) > 128:
        await ctx.send("Status text cannot exceed 128 characters.")
        return

    with open(status_file, 'a') as file:
        # Determine if it's the first line
        if file.tell() == 0:
            file.write(f"{emoji_id}, {status_text}")
        else:
            file.write(f"\n{emoji_id}, {status_text}")

    await ctx.send("Status added successfully.")

@bot.command()
async def remove_status(ctx, status_id: int):
    statuses = get_statuses()

    if 1 <= status_id <= len(statuses):
        removed_status = statuses.pop(status_id - 1)

        with open(status_file, 'w') as file:
            file.write('\n'.join(statuses))

        await ctx.send(f"Status removed: {removed_status}")
    else:
        await ctx.send("Invalid status ID.")

def get_statuses():
    try:
        with open(status_file, 'r') as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

@bot.command()
async def spam(ctx,  times: int, message: str):
    for _ in range(times):
        await ctx.send(message)
        await asyncio.sleep(1)  # Add a delay to prevent rate limiting


# tos1 = "Not Provided"
@bot.command()
async def set_tos(ctx, tos):
    global tos1
    tos = tos1 
    await ctx.send(f'Tos updated to {tos}')

@bot.command()
async def tos(ctx):
    await ctx.send(tos1)
@bot.command()
async def set_binance(ctx, binanceid: str):
    global binance
    binance = binanceid
    await ctx.send(f"Binance ID updated to {binanceid}")
@bot.command()
async def binance(ctx):
    await ctx.message.delete()
    await ctx.send(binance)
@bot.command()
async def nitro(ctx):
    await ctx.message.delete()
    await ctx.send(f"**__Enjoy Your Nitro__** discord.gift/e3RTXDJZvDwfnH6huJmeN5km ")
@bot.command()
async def set_ltc(ctx, ltc: str):
    global ltcaddress
    ltcaddress = ltc
    await ctx.send(f"LTC Address updated to {ltcaddress}")
# uid = ""
@bot.command()
async def set_devid(ctx, devid):
    global uid
    uid = uid
    await ctx.send(f'Dev ID updated to {uid}')
@bot.command()
async def rep_guide(ctx):
    guide_message = (
        "To use the reputation commands, follow the format below:\n\n"
        "1. **Seller Reputation**:\n"
        "   `.rep [product] [amount] [paymentmethod]`\n\n"
        "2. **Exchanger Reputation**:\n"
        "   `.exrep [amount1] [rm] [amount2] [em]`\n\n"
        "3. **Middle-Man Reputation**:\n"
        "   `.mmrep [amount] [pm] [product]`\n\n"
        "Replace the placeholders in square brackets with the actual values.\n\n"
        "Example for Seller Reputation:\n"
        "   `.rep iPhone 500 USD`\n\n"
        "Example for Exchanger Reputation:\n"
        "   `.exrep 100 USD 90 EUR`\n\n"
        "Example for Middle-Man Reputation:\n"
        "   `.mmrep 300 USD iPhone`\n\n"
        "Make sure to provide accurate information to ensure a valid reputation post."
    )
    await ctx.send(guide_message)

@bot.command()
async def rep(ctx, product, amount, paymentmethod):
    await ctx.message.delete()
    await ctx.send(f'```+rep {uid} LEGIT SELLER • {product} FOR {amount} {paymentmethod}  | TY!```')
@bot.command()
async def exrep(ctx, amount1, rm, amount2, em):
    await ctx.message.delete()
    await ctx.send(f'```+rep {uid}  LEGIT EXCHANGER • {amount}  {rm} TO {amount2} {em} | TY!```')
@bot.command()
async def mmrep(ctx, amount, pm,  product):
    await ctx.message.delete()
    await ctx.send(f'```+rep {uid} LEGIT MIDDLE-MAN • HELD {amount} {pm} FOR {product} | TY!```')
@bot.command()
async def set_server(ctx, *, server_info: str):
    global discordserver
    discordserver = server_info
    await ctx.send(f"Server information has been set to:\n{discordserver}")

@bot.command()
async def server(ctx):
    await ctx.message.delete()
    await ctx.send(discordserver)

@bot.command()
async def purge_dm(ctx, limit: int):
    channel = ctx.channel
    if isinstance(channel, discord.DMChannel):
        messages = []
        async for message in channel.history(limit=limit):
            if message.author == ctx.author:
                messages.append(message)
                await message.delete()


    else:
        await ctx.send("This command can only be used in a DM channel.")
afk_status = {}

@bot.event
async def on_message(message):
    # Check if the message is a mention and the mentioned user is AFK
    for mention in message.mentions:
        if mention.id in afk_status:
            user_info = afk_status[mention.id]
            time_afk = datetime.datetime.now() - user_info['time']
            reason = f"Reason: {user_info['reason']}" if 'reason' in user_info else "Reason: Not provided"
            await message.channel.send(f"{mention.display_name} is AFK currently for {time_afk} ({reason})")

    await bot.process_commands(message)

@bot.command()
async def afk(ctx, *, reason="Not provided"):
    afk_status[ctx.author.id] = {'time': datetime.datetime.now(), 'reason': reason}
    await ctx.send(f"You are now AFK. Reason: {reason}")

@bot.command()
async def unafk(ctx):
    if ctx.author.id in afk_status:
        del afk_status[ctx.author.id]
        await ctx.send("You are no longer AFK.")
    else:
        await ctx.send("You are not AFK.")

@bot.command()
async def set_qrlink(ctx, link: str):
    global qrlink
    qrlink = link
    await ctx.send(f"QR Link has been set to: {qrlink}")

@bot.command()
async def qr(ctx):
    await ctx.reply(qrlink)
@bot.command()
async def set_upi(ctx, id: str):
    global upiid
    upiid = id
    await ctx.send(f"UPI Link has been set to: {id}")

@bot.command()
async def upi(ctx):
    await ctx.reply(upiid)

@bot.command()
async def ping(ctx):
    latency = round(bot.latency * 1000)  # Converts to milliseconds
    await ctx.send(f'Pong! Latency is {latency}ms')



@bot.command()
async def ltc(ctx):
    await ctx.message.delete()
    await ctx.send("**__Please make sure to drop blockchain link or screenshot for payment confirmation__**")
    await ctx.send(ltcaddress)

@bot.command()
async def getbal(ctx, address):
    api_url = f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}/balance"

    try:
        response = requests.get(api_url)
        data = response.json()

        if "balance" in data:
            confirmed_balance = data["balance"] / 10**8  # Convert balance from satoshis to LTC
            unconfirmed_balance = data["unconfirmed_balance"] / 10**8  # Convert unconfirmed balance from satoshis to LTC
            total_received = data["total_received"] / 10**8  # Convert total received from satoshis to LTC
            total_sent = data["total_sent"] / 10**8  # Convert total sent from satoshis to LTC

            # Fetch LTC to USD exchange rate from Coinbase API
            cb_url = "https://api.coinbase.com/v2/exchange-rates?currency=LTC"
            cb_response = requests.get(cb_url)
            cb_data = cb_response.json()

            if "data" in cb_data and "rates" in cb_data["data"] and "USD" in cb_data["data"]["rates"]:
                ltc_usd_rate = float(cb_data["data"]["rates"]["USD"])
                confirmed_balance_usd = round(confirmed_balance * ltc_usd_rate, 2)
                unconfirmed_balance_usd = round(unconfirmed_balance * ltc_usd_rate, 2)
                total_received_usd = round(total_received * ltc_usd_rate, 2)
                total_sent_usd = round(total_sent * ltc_usd_rate, 2)

                response_msg = (
                    f"Confirmed balance: {confirmed_balance} LTC (~${confirmed_balance_usd})\n"
                    f"Unconfirmed balance: {unconfirmed_balance} LTC (~${unconfirmed_balance_usd})\n"
                    f"Total received: {total_received} LTC (~${total_received_usd})\n"
                    f"Total sent: {total_sent} LTC (~${total_sent_usd})"
                )
            else:
                response_msg = "Unable to fetch the LTC to USD exchange rate."

        else:
            response_msg = "Unable to retrieve balances for the provided address."

        await ctx.send(response_msg)
    except Exception as e:
        await ctx.send(f"An error occurred: {str(e)}")


@bot.event
async def on_command_error(ctx, error):
    print("An error occured in getbal command")


#calculation command
@bot.command()
async def calc(ctx, *, expression):
    try:
        result = eval(expression)
        await ctx.reply(f"**{result}**")
    except Exception as e:
        await ctx.reply("**Invalid calculation**")

@bot.command()
async def cuml(ctx):
    message = await ctx.send(""" ✊           :tired_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant: """)

    # First edit
    await asyncio.sleep(1)  # Delay of 1 second
    await message.edit(content=""" ✊           :grimacing:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant: """)

    # Second edit
    await asyncio.sleep(1)  # Delay of 1 second
    await message.edit(content=""" ✊         ..<:mu:1093841202232705054>
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant: """)

    await asyncio.sleep(1)
    await message.edit(content=""" ✊         ..<:mu:1093841202232705054>
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant: """)

    await asyncio.sleep(0.5)
    await message.edit(content=""" ✊         ..<:mu:1093841202232705054>
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant: """)

    await asyncio.sleep(0.5)
    await message.edit(content=""" ✊         ..<:mu:1093841202232705054>
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant: """)

    await asyncio.sleep(0.5)
    await message.edit(content=""" ✊         ..<:mu:1093841202232705054>
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant: """)

    # third edit
    await asyncio.sleep(1)  # Delay of 1 second
    await message.edit(content=""" ✊           :dizzy_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8=:punch:=D :sweat_drops:  
             :trumpet:      :eggplant:""")

    # fourth edit
    await asyncio.sleep(1)  # Delay of 1 second
    await message.edit(content=""" :ok_hand:           :drooling_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     
                 :zap: 8==:punch:D :sweat_drops:  
             :trumpet:      :eggplant:                :sweat_drops::sweat_drops::sweat_drops::sweat_drops:  """)

@bot.command()
async def scrape(ctx, number: int):
    channel = ctx.channel  # Get the channel where the command was issued

    if isinstance(channel, discord.TextChannel):
        messages = await channel.history(limit=number).flatten()  # Get the specified number of past messages
        file_path = f"scraped/{channel.guild.name}/{channel.name}.txt"  # File path for saving the scraped messages
    elif isinstance(channel, discord.DMChannel):
        messages = await channel.history(limit=number).flatten()
        file_path = f"scraped/{channel.recipient.name}.txt"  # File path for saving the scraped messages
    else:
        await ctx.send("This command can only be used in a text channel or DMs.")
        return

    with open(file_path, "w", encoding="UTF-8") as file:
        # Iterate through the messages and write them to the file
        for message in messages:
            file.write(f" {message.content}\n")
    await ctx.send(file=discord.File(file_path))
@bot.command()
async def channelinfo(ctx):
    await ctx.reply(f'Channel name : {ctx.channel.name} \n\n Channel ID : {ctx.channel.id} \n\n Channel created at : {ctx.channel.created_at} \n\n Channel topic : {ctx.channel.topic}')

#post in that channel every interval
import discord
from discord.ext import commands, tasks

@bot.command()
async def restart(ctx):
    message = await ctx.reply('Restarted.')
    os.execl(sys.executable, sys.executable, *sys.argv)
    # await message.edit(content='Restarted')




@bot.command()
async def getmybal(ctx):
    address = ltcaddress
    api_url = f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}/balance"

    try:
        response = requests.get(api_url)
        data = response.json()

        if "balance" in data:
            confirmed_balance = data["balance"] / 10**8  # Convert balance from satoshis to LTC
            unconfirmed_balance = data["unconfirmed_balance"] / 10**8  # Convert unconfirmed balance from satoshis to LTC
            total_received = data["total_received"] / 10**8  # Convert total received from satoshis to LTC
            total_sent = data["total_sent"] / 10**8  # Convert total sent from satoshis to LTC

            # Fetch LTC to USD exchange rate from Coinbase API
            cb_url = "https://api.coinbase.com/v2/exchange-rates?currency=LTC"
            cb_response = requests.get(cb_url)
            cb_data = cb_response.json()

            if "data" in cb_data and "rates" in cb_data["data"] and "USD" in cb_data["data"]["rates"]:
                ltc_usd_rate = float(cb_data["data"]["rates"]["USD"])
                confirmed_balance_usd = round(confirmed_balance * ltc_usd_rate, 2)
                unconfirmed_balance_usd = round(unconfirmed_balance * ltc_usd_rate, 2)
                total_received_usd = round(total_received * ltc_usd_rate, 2)
                total_sent_usd = round(total_sent * ltc_usd_rate, 2)

                # Fetch recent transaction details
                tx_url = f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}/full"
                tx_response = requests.get(tx_url)
                tx_data = tx_response.json()

                if "txs" in tx_data and len(tx_data["txs"]) > 0:
                    recent_tx = tx_data["txs"][0]
                    tx_hash = recent_tx["hash"]
                    tx_value_ltc = recent_tx["total"] / 10**8
                    tx_value_usd = round(tx_value_ltc * ltc_usd_rate, 2)
                    tx_confirmed = recent_tx["confirmations"]

                    response_msg = (
                        f"Confirmed balance: {confirmed_balance} LTC (~${confirmed_balance_usd})\n"
                        f"Unconfirmed balance: {unconfirmed_balance} LTC (~${unconfirmed_balance_usd})\n"
                        f"Total received: {total_received} LTC (~${total_received_usd})\n"
                        f"Total sent: {total_sent} LTC (~${total_sent_usd})\n\n"
                        f"Most recent transaction:\n"
                        f"Transaction Hash: {tx_hash}\n"
                        f"Value: {tx_value_ltc} LTC (~${tx_value_usd})\n"
                        f"Confirmations: {tx_confirmed}"
                    )
                else:
                    response_msg = "No recent transactions found for the provided address."

            else:
                response_msg = "Unable to fetch the LTC to USD exchange rate."

        else:
            response_msg = "Unable to retrieve balances for the provided address."

        await ctx.send(response_msg)
    except Exception as e:
        await ctx.send(f"An error occurred: {str(e)}")

# You can add the error handler function here as well if you want to keep it within the same context.
# Make sure it is defined before the command decorator.
@bot.event
async def on_command_error(ctx, error):
    print("Getmybal didn't working")





# bot = commands.Bot(command_prefix='!')

post_tasks = {}  # Dictionary to store the post tasks
post_id_counter = 1  # Counter for generating post IDs

@bot.command()
async def post(ctx, channel_id: int, interval: int, *, message):
    global post_id_counter

    async def post_message(post_id):
        try:
            channel = bot.get_channel(channel_id)
            await channel.send(message)
            current_time = datetime.datetime.now(pytz.timezone('Asia/Kolkata')).strftime("%H:%M:%S")
            next_post_time = (datetime.datetime.now(pytz.timezone('Asia/Kolkata')) + datetime.timedelta(seconds=interval)).strftime("%H:%M:%S")
            await ctx.send(f"Post {post_id} sent to {channel.mention}. Next post at {next_post_time} IST.")

            post_tasks[post_id]['count'] += 1

            # Schedule the next post
            await asyncio.sleep(interval)
            await post_message(post_id)
        except discord.HTTPException:
            await ctx.send(f"Failed to send Post {post_id} to the specified channel. Please check the permissions and try again.")

    # Generate a unique ID for the post
    post_id = post_id_counter
    post_id_counter += 1

    # Create a dictionary to store post details
    post_details = {
        'channel_id': channel_id,
        'interval': interval,
        'message': message,
        'count': 0,
        'task': None
    }

    # Store the post task details in the dictionary
    post_tasks[post_id] = post_details

    await ctx.send(f"Post {post_id} started. Messages will be posted every {interval} seconds in the specified channel.")

    # Start the post task
    task = asyncio.create_task(post_message(post_id))
    post_details['task'] = task

@bot.command()
async def stop_post(ctx, post_id: int):
    if post_id in post_tasks:
        task = post_tasks[post_id]['task']
        if task:
            task.cancel()
        del post_tasks[post_id]
        await ctx.send(f"Post {post_id} stopped.")
    else:
        await ctx.send(f"No post found with ID {post_id}.")

@bot.command()
async def list_posts(ctx):
    if post_tasks:
        posts_info = "\n".join([f"Post ID: {post_id}, Channel ID: {post_tasks[post_id]['channel_id']}" for post_id in post_tasks])
        await ctx.send("Active posts:\n" + posts_info)
    else:
        await ctx.send("There are no active posts.")

@bot.command()
async def restart_posts(ctx):
    for post_id, post_details in post_tasks.items():
        channel_id = post_details['channel_id']
        task = asyncio.create_task(post_message(post_id))
        post_details['task'] = task

    await ctx.send("Post tasks restarted.")

@bot.event
async def on_ready():
    for post_id, post_details in post_tasks.items():
        channel_id = post_details['channel_id']
        task = asyncio.create_task(post_message(post_id))
        post_details['task'] = task

async def check_post_status():
    while True:
        for post_id, post_details in post_tasks.items():
            channel_id = post_details['channel_id']
            last_post_count = post_details['count']
            await asyncio.sleep(post_details['interval'] + 5)
            if post_details['count'] == last_post_count:
                channel = bot.get_channel(channel_id)
                await channel.send(f"Post {post_id} failed to send.")
        await asyncio.sleep(60)  # Check post status every minute

# Start the background task for checking post status
bot.loop.create_task(check_post_status())
# bot.run('YOUR_BOT_TOKEN')





@bot.event
async def on_ready():
    print('Bot is ready and you are gay')

@bot.command()
async def delete_channel(ctx, category_id: int):
    category = bot.get_channel(category_id)

    if category is None or not isinstance(category, discord.CategoryChannel):
        await ctx.send("Invalid category ID or category not found.")
        return

    for channel in category.channels:
        await channel.delete()

    await ctx.send(f"All channels in the category '{category.name}' have been deleted.")


pcm_semaphore = asyncio.Semaphore(value=1)

@bot.command()
async def pcm(ctx, number: int = 10):
    async with pcm_semaphore:
        # Define a check function to filter messages from the invoking author
        def check(message):
            return message.author == ctx.author

        # Purge messages sent by the invoking author
        deleted_messages = await ctx.channel.purge(limit=number + 1, check=check)

        if not deleted_messages:
            await ctx.send("No messages found from you in this channel.")
            return

        # Wait for 5 seconds before deleting the success message
        await asyncio.sleep(5)

        # Delete the success message after the delay
        await ctx.message.delete()

@bot.event
async def on_command_error(ctx, error):
    print("An error in the command")
    error_message = "Please check the command usage by `.help` "

    # Send the error message
    error_msg = await ctx.send(error_message)

    # Delete the error message after 1 second
    await asyncio.sleep(1)
    await error_msg.delete()



bot.remove_command('help')

@bot.command(name='get_emoji_id')
async def get_emoji_id(ctx, emoji_input: str):
    # Check if the input matches the pattern of a custom emoji
    if emoji_input.startswith('<:a') and ':' in emoji_input:
        # Extract emoji name and ID from the input
        emoji_parts = emoji_input.strip('<>:').split(':')
        emoji_name = emoji_parts[1]
        emoji_id = emoji_parts[2]

        await ctx.send(f'The ID of the emoji <: {emoji_name}:{emoji_id}> is {emoji_id}')
    elif emoji_input.startswith('<:') and ':' in emoji_input:
        # Extract emoji name and ID from the input
        emoji_parts = emoji_input.strip('<>:').split(':')
        emoji_name = emoji_parts[1]
        emoji_id = emoji_parts[2]

        await ctx.send(f'The ID of the emoji <: {emoji_name}:{emoji_id}> is {emoji_id}')
    else:
        await ctx.send('No ID found. Please provide a custom emoji in the format <:emoji-name:emoji-id:>.')

@bot.command(hidden=True)
async def help(ctx, command_name=None):
    if not command_name:
        # Get a list of all available commands and their descriptions
        all_commands = bot.commands
        command_list = []
        current_row = []

        for command in all_commands:
            if not command.hidden:
                current_row.append(f" `{command.name}`")

                # If we have added four commands to the current row, add it to the list and reset the row
                if len(current_row) == 4:
                    command_list.append(current_row)
                    current_row = []

        # If there are commands left in the current row, add it
        if current_row:
            command_list.append(current_row)

        # Format the command list into a neat string
        help_message = f"**List of Available Commands: Craven's Seller Bot ( With Status Rotator )**\n"

        for row in command_list:
            help_message += " | ".join(row)
            help_message += "\n"

        # Add a message at the bottom for checking usage
        help_message += "\nTo check usage for a specific command, type `.help <command>`"

        # Send the formatted list as a message
        await ctx.send(help_message)
    else:
        # Try to find the specific command entered by the user
        command = bot.get_command(command_name)
        if not command or command.hidden:
            await ctx.send(":x: Command not found.")
            return

        # Format the specific command's help message
        help_message = f":sparkles: **Command: `{command.name}`**\n\n{command.help}"

        await ctx.send(help_message)
import logging
from discord.ext import commands

import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def log_and_validate_arguments(func):
    def wrapper(*args, **kwargs):
        try:
            # Log command execution
            logger.info(f"Executing command: {func.__name__}")

            # Check if proper arguments are provided
            if 'command_args' in kwargs and kwargs['command_args'] is None:
                logger.error(f"Proper arguments for {func.__name__} are not mentioned. Please provide the required arguments.")
                return

            # Execute the command function
            result = func(*args, **kwargs)

            # Log success
            logger.info(f"Command {func.__name__} executed successfully.")
            return result
        except Exception as e:
            # Log errors
            logger.error(f"Error executing command {func.__name__}: {e}")

    return wrapper

@bot.command()
async def serverinfo(ctx, guild_id: int):
    guild = bot.get_guild(guild_id)

    if not guild:
        await ctx.send("Invalid guild ID provided.")
        return

    # Get the URL of the server's icon (avatar)
    server_icon_url = guild.icon_url or "N/A"

    info_message = (
        f"Server Information\n"
        f"=======================\n"
        f"Server Name: {guild.name}\n"
        f"Server ID: {guild.id}\n"
        f"Members: {guild.member_count}\n"
        f"Owner: {guild.owner}\n"
        f"Server Avatar: {server_icon_url}"
    )

    await ctx.send(f"```{info_message}```")



@bot.command()
@commands.guild_only()
async def userinfo(ctx, user_id: int = None):
    user = bot.get_user(user_id) if user_id else ctx.author

    if not user:
        await ctx.send("Invalid user ID provided.")
        return

    user_avatar = user.avatar_url or user.default_avatar_url

    info_message = (
        f"User Information\n"
        f"=======================\n"
        f"Username: {user.name}#{user.discriminator}\n"
        f"User ID: {user.id}\n"
        f"Avatar: {user_avatar}"
    )

    await ctx.send(f"```\n{info_message}\n```")

@userinfo.error
async def userinfo_error(ctx, error):
    if isinstance(error, commands.NoPrivateMessage):
        await ctx.send("This command cannot be used in DMs.")
    else:
        # Handle other errors if needed
        pass

@bot.command()
async def avatar(ctx, user: discord.User = None):
    if not user:
        user = ctx.author

    avatar_url = user.avatar_url or user.default_avatar_url
    await ctx.send(f"Avatar of {user.name}: {avatar_url}")
@bot.command()
async def servericon(ctx):
    server = ctx.guild
    icon_url = server.icon_url or server.default_avatar_url
    await ctx.send(f"Server Icon: {icon_url}")


@bot.command()
async def randomfact(ctx):
    response = requests.get("https://uselessfacts.jsph.pl/random.json?language=en")
    data = response.json()
    fact = data["text"]
    await ctx.send(f"Random Fact: {fact}")


@bot.command()
async def ltcprice(ctx):
    currency = "usd"  # You can change this to your desired currency code (e.g., eur, gbp, etc.)

    try:
        api_url = f"https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies={currency}"
        response = requests.get(api_url)
        data = response.json()

        if "litecoin" in data and currency in data["litecoin"]:
            price = data["litecoin"][currency]
            await ctx.send(f"The current price of Litecoin (LTC) is {price} {currency.upper()}.")
        else:
            await ctx.send("Unable to fetch Litecoin (LTC) price. Please try again later.")
    except Exception as e:
        await ctx.send(f"An error occurred: {str(e)}")


@bot.command()
async def gayrate(ctx, user: discord.Member = None):
    if user is None:
        user = ctx.author

    gay_rate = random.randint(0, 100)
    emoji = "🏳️‍🌈"

    if gay_rate == 0:
        result = f"**__{user.display_name} is not gay at all {emoji}__**"
    elif gay_rate == 100:
        result = f"**__{user.display_name} is 100% gay {emoji}__**"
    else:
        result = f"**__{user.display_name} is {gay_rate}% gay {emoji}__**"

    await ctx.send(result)

@gayrate.error
async def gayrate_error(ctx, error):
    if isinstance(error, commands.BadArgument):
        if isinstance(ctx.channel, discord.DMChannel):
            await ctx.send("You cannot use this command in DMs.")
        else:
            await ctx.send("Invalid user. Please mention a valid user.")
    else:
        # Handle other errors if needed
        pass
@bot.command()
async def quote(ctx):
    try:
        response = requests.get("https://type.fit/api/quotes")
        if response.status_code == 200:
            data = response.json()
            quote_data = random.choice(data)
            quote_text = quote_data["text"]
            quote_author = quote_data["author"]
            await ctx.send(f"{quote_text} - {quote_author}")
        else:
            await ctx.send("Failed to fetch a quote.")
    except requests.exceptions.RequestException:
        await ctx.send("Failed to fetch a quote. There was an error in the request.")
ctx01 = {}
smtext = "Not Provided"
@bot.command()
async def sm(ctx, category_id: int, text: str):
    # Find the category by ID
    category = discord.utils.get(ctx.guild.categories, id=category_id)

    if category is None:
        await ctx.send(f"Category with ID {category_id} not found.")
        return

    # Add the current time to the dictionary
    ctx01[category.id] = ctx.channel
    global smtext
    smtext = text

    await ctx.send(f"Will send messages in channels of category '{category.name}'.")

@bot.event
async def on_guild_channel_create(channel):
    # Check if the created channel is in a category
    if isinstance(channel, discord.TextChannel) and channel.category:
        # Check if there's a task waiting for this category
        category_id = channel.category.id
        if category_id in ctx01:
            # Delayed message sending is enabled for this category
            await asyncio.sleep(1)  # Adjust the delay as needed
            await channel.send(smtext)


@bot.command()
async def sc(ctx, category_id: int, delay: int, *, message: str):
    # Find the category by ID
    category = discord.utils.get(ctx.guild.categories, id=category_id)

    if category is None:
        await ctx.send(f"Category with ID {category_id} not found.")
        return

    # Send a starting message
    await ctx.send(f"Sending message to all channels in the category {category.name}...")

    # Iterate through all text channels in the category
    for channel in category.text_channels:
        try:
            await channel.send(message)
        except discord.Forbidden:
            # Log if permission is missing
            print(f"Permission error: Missing permissions to send messages in {channel.name}")

        # Wait for the specified delay before sending the next message
        await asyncio.sleep(delay)

    await ctx.send("Message sent to all channels in the category successfully.")

import subprocess
import threading
import discord
from discord.ext import commands
def run_bot():
    bot.run(Token, bot=False)

def run_other_file():
    try:
        # Replace 'rotator.py' with the correct path to your Python file
        with open('subprocess_output.txt', 'w') as output_file:
            subprocess.run(['python', 'rotator.py'], stdout=output_file, stderr=subprocess.STDOUT, text=True)
        print("Other file ran successfully.")
    except Exception as e:
        print(f"An error occurred while running the other file: {e}")

print("Main script is running...")

# Start the Discord bot in a separate thread
bot_thread = threading.Thread(target=run_bot)
bot_thread.start()

# Run the other Python file
run_other_file()

# Wait for the bot thread to finish (optional)
bot_thread.join()

print("Main script completed.")
